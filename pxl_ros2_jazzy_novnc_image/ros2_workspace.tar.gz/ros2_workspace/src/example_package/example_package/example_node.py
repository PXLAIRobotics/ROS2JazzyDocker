def main():
    print('Hi from example_package.')


if __name__ == '__main__':
    main()
